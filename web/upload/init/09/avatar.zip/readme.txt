
[utopiafonts] 1999 free font
----------------------------------------------------

this font is provided free for personal or commercial use,
it can be redistributed however it may not be sold.  

HANDWRITING FONTS
-----------------
sorry people, but I have stopped doing free handwriting fonts
because it has got to be too time consuming, I will however
consider making your handwriting into a font if you can convince
me. send gifts to:
		  	Dale Thorpe
			c/o BSSC
			P.O.BOX 545
			Bendigo, Victoria,
			Australia 3550.

MAILING LIST
------------
join the utopiafonts mailing list by sending a blank email to:
subscribe-utopiafonts@egroups.com or just visit our webpage at:

http://utopiafonts.cjb.net/

----------------------------------------------------
� 1999 utopiafonts. dale_thorpe@bssc.edu.au