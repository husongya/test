Atomic Regular (Re-release)

Background
Thank you for downloading this font. I can't remember how I came about doing this font, since the original version was created about 6 years ago. In this re-release, I've tuned up a lot of the kerning paris, to make it more usable. This font is suitable only for short headlines, or as background noise. Warning: using sparingly, lest running the risk of creating typography holocaust. You have been warned ;)
 
Enjoy using these fonts as much as I have in creating them.

Technical information
Only the basic set of characters are included, alphabets and numbers and limited symbols and punctuation.

Using the font
You may use this font for FREE commercially and non-commercially. All I ask for is that you send me a screenshot or a scanned picture of its application, or send me the URL to the website that you used it on, as I'd like to see how far these fonts go. And if I get a lot of these, I might set up a page to showcase your works that incorporate my fonts.

Distribution
You may redistribute this set provided that you keep all the fonts as a set and this readme file together. If you wish to include this set in a magazine/book CD-ROM, I would like to have a copy of the magazine sent to me. Please e-mail me for the address to send it to. You may not re-sell or re-edit this font without the expressed permission from me. Doing so will be very uncool, not to mention unethical of you.

Contacting the author
creator: Sean Liew
website: http://www.cmonsta.com
e-mail: sean@cmonsta.com

May 2002 � The font Atomic Regular is (c) 2002 Liew Kheng Huat, All rights reserved