This font is a freeware but you need my permission to show it on your website. All rights is reserved to DesignByLime lime@graphic-designer.com

http://www.houseoflime.com